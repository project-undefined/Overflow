package chainmanager

import (
	"github.com/iotaledger/goshimmer/packages/core/commitment"
)

type ChainID = commitment.ID
