package protocol

import (
	"github.com/iotaledger/goshimmer/packages/core/database"
)

const DatabaseVersion database.Version = 1
