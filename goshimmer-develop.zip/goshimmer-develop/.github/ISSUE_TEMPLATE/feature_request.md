---
name: Request a feature for GoShimmer
about: Request a feature
---

## Description

Briefly describe the feature that you are requesting.

## Motivation

Explain why this feature is needed.

## Requirements

Write a list of what you want this feature to do.

1. 
2. 
3. 

## Open questions (optional)

Use this section to ask any questions that are related to the feature.

## Are you planning to do it yourself in a pull request?

Yes/No.
